import vk_api
from vk_api.longpoll import VkLongPoll, VkEventType
import sys
import random
import Hello_ans
import Bye_ans
import Crafts
import requests
import Help


TOKEN = '1cd9656ca91204a43ec02e9e5ec617e6dfcb9f7ce5f9955b4c5a1405210702902ddc862345c1556fcc761'

vk = vk_api.VkApi(token=TOKEN)
longpoll = VkLongPoll(vk)
upload = vk_api.upload.VkUpload(vk)


def send_messages (chat_id, text):
    random_id = random.randint(0, 1000000)
    vk.method('messages.send', {'chat_id': chat_id, 'message': text, 'random_id': random_id})


def send_photos (chat_id, att):
    random_id = random.randint(0, 1000000)
    vk.method('messages.send', {'chat_id': chat_id, 'attachment': att, 'random_id': random_id})


for event in longpoll.listen():
    print(event.type)
    if event.type == VkEventType.MESSAGE_NEW:
        if event.to_me:
            if event.from_chat:
                msg = event.text
                chat_id = event.chat_id

                if '!крафт' == msg[:6]:
                    photo = Crafts.crafts[msg[7:]][0]
                    text = Crafts.crafts[msg[7:]][1]
                    send_photos(chat_id, photo)

                elif 'привет' in msg.lower():
                    text = random.choice(Hello_ans.hello)

                elif 'пока' in msg.lower():
                    text = random.choice(Bye_ans.bye)

                elif msg == 'help':
                    text = Help.a

                else:
                    text = 'Извините, я Вас не понимаю...'

                send_messages(chat_id, text)




